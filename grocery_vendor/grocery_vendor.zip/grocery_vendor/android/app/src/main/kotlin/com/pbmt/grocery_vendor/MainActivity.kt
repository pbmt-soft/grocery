package com.pbmt.grocery_vendor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
